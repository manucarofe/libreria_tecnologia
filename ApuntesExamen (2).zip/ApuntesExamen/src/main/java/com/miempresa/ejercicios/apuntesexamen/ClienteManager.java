package com.miempresa.ejercicios.apuntesexamen;

import java.sql.*;
import java.util.*;
/**
 *
 * @author manue
 */

import java.sql.*;
import java.util.*;

public class ClienteManager {
    private Connection conn;

    public ClienteManager(Connection conn) {
        this.conn = conn;
    }

    // CREAR
    public void crear(ClienteBase obj) throws SQLException {
        if (obj instanceof Cliente c) {
            String sql = "INSERT INTO clientes (nombre, email) VALUES (?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, c.getNombre());
                ps.setString(2, c.getEmail());
                ps.executeUpdate();
            }
        } else if (obj instanceof Pedido p) {
            String sql = "INSERT INTO pedidos (producto, cantidad, cliente_id) VALUES (?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, p.getNombre());
                ps.setInt(2, p.getCantidad());
                ps.setInt(3, p.getClienteId());
                ps.executeUpdate();
            }
        }
    }

    // LEER
    public List<Cliente> listarClientes() throws SQLException {
        List<Cliente> lista = new ArrayList<>();
        String sql = "SELECT * FROM clientes";
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Cliente(rs.getInt("id"), rs.getString("nombre"), rs.getString("email")));
            }
        }
        return lista;
    }

    public List<Pedido> listarPedidos() throws SQLException {
        List<Pedido> lista = new ArrayList<>();
        String sql = "SELECT * FROM pedidos";
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Pedido(rs.getInt("id"), rs.getString("producto"), rs.getInt("cantidad"), rs.getInt("cliente_id")));
            }
        }
        return lista;
    }

    // ACTUALIZAR
    public void actualizar(ClienteBase obj) throws SQLException {
        if (obj instanceof Cliente c) {
            String sql = "UPDATE clientes SET nombre=?, email=? WHERE id=?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, c.getNombre());
                ps.setString(2, c.getEmail());
                ps.setInt(3, c.getId());
                ps.executeUpdate();
            }
        } else if (obj instanceof Pedido p) {
            String sql = "UPDATE pedidos SET producto=?, cantidad=?, cliente_id=? WHERE id=?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, p.getNombre());
                ps.setInt(2, p.getCantidad());
                ps.setInt(3, p.getClienteId());
                ps.setInt(4, p.getId());
                ps.executeUpdate();
            }
        }
    }

    // BORRAR
    public void eliminar(String tabla, int id) throws SQLException {
        String sql = "DELETE FROM " + tabla + " WHERE id=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}

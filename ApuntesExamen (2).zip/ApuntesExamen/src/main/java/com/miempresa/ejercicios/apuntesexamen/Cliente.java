package com.miempresa.ejercicios.apuntesexamen;

/**
 *
 * @author manue
 */
public class Cliente extends ClienteBase {
    private String email;

    public Cliente(int id, String nombre, String email) {
        super(id, nombre);
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    @Override
    public String mostrarDatos() {
        return "Cliente: " + nombre + " | Email: " + email;
    }
}


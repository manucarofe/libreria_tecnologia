package com.miempresa.ejercicios.apuntesexamen;

import java.sql.*;

/**
 *
 * @author manue
 */

public class DBConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/gestion_clientes?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASS = "";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }
}



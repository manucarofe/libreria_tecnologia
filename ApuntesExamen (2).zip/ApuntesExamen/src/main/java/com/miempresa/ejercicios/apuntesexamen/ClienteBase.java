package com.miempresa.ejercicios.apuntesexamen;

/**
 *
 * @author manue
 */
public abstract class ClienteBase {
    protected int id;
    protected String nombre;

    public ClienteBase(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public abstract String mostrarDatos();
    public int getId() { return id; }
    public String getNombre() { return nombre; }
}


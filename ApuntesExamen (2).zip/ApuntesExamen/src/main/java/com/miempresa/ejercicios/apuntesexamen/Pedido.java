package com.miempresa.ejercicios.apuntesexamen;

/**
 *
 * @author manue
 */

public class Pedido extends ClienteBase {
    private int cantidad;
    private int clienteId;

    public Pedido(int id, String producto, int cantidad, int clienteId) {
        super(id, producto);
        this.cantidad = cantidad;
        this.clienteId = clienteId;
    }

    public int getCantidad() { return cantidad; }
    public int getClienteId() { return clienteId; }

    @Override
    public String mostrarDatos() {
        return "Pedido: " + nombre + " | Cantidad: " + cantidad + " | Cliente ID: " + clienteId;
    }
}

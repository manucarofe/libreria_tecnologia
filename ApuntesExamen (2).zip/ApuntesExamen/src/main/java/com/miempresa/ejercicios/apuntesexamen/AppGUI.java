package com.miempresa.ejercicios.apuntesexamen;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.util.List;

/**
 *
 * @author manue
 */
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;



public class AppGUI extends JFrame {
    private ClienteManager crud;
    private DefaultTableModel clienteModel, pedidoModel;

    public AppGUI() throws SQLException {
        crud = new ClienteManager(DBConnection.getConnection());

        setTitle("Gestión Clientes y Pedidos");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 600);
        setLayout(new GridLayout(2, 1));

        // PANEL CLIENTES
        JPanel clientePanel = new JPanel(new BorderLayout());
        clientePanel.setBorder(BorderFactory.createTitledBorder("Clientes"));
        clientePanel.setBackground(new Color(230, 255, 230));

        JPanel formCliente = new JPanel(new GridLayout(3, 2));
        JTextField txtIdCliente = new JTextField();
        JTextField txtNombre = new JTextField();
        JTextField txtEmail = new JTextField();

        formCliente.add(new JLabel("ID:")); formCliente.add(txtIdCliente);
        formCliente.add(new JLabel("Nombre:")); formCliente.add(txtNombre);
        formCliente.add(new JLabel("Email:")); formCliente.add(txtEmail);

        JPanel btnsCliente = new JPanel();
        JButton btnCrearC = new JButton("Crear");
        JButton btnLeerC = new JButton("Leer");
        JButton btnActualizarC = new JButton("Actualizar");
        JButton btnEliminarC = new JButton("Eliminar");
        btnCrearC.setBackground(Color.GREEN);
        btnEliminarC.setBackground(Color.RED);
        btnActualizarC.setBackground(Color.ORANGE);

        btnsCliente.add(btnCrearC); btnsCliente.add(btnLeerC);
        btnsCliente.add(btnActualizarC); btnsCliente.add(btnEliminarC);

        clienteModel = new DefaultTableModel(new Object[]{"ID", "Nombre", "Email"}, 0);
        JTable clienteTable = new JTable(clienteModel);

        clientePanel.add(formCliente, BorderLayout.NORTH);
        clientePanel.add(new JScrollPane(clienteTable), BorderLayout.CENTER);
        clientePanel.add(btnsCliente, BorderLayout.SOUTH);

        // PANEL PEDIDOS
        JPanel pedidoPanel = new JPanel(new BorderLayout());
        pedidoPanel.setBorder(BorderFactory.createTitledBorder("Pedidos"));
        pedidoPanel.setBackground(new Color(255, 230, 230));

        JPanel formPedido = new JPanel(new GridLayout(4, 2));
        JTextField txtIdPedido = new JTextField();
        JTextField txtProducto = new JTextField();
        JTextField txtCantidad = new JTextField();
        JTextField txtClienteId = new JTextField();

        formPedido.add(new JLabel("ID Pedido:")); formPedido.add(txtIdPedido);
        formPedido.add(new JLabel("Producto:")); formPedido.add(txtProducto);
        formPedido.add(new JLabel("Cantidad:")); formPedido.add(txtCantidad);
        formPedido.add(new JLabel("Cliente ID:")); formPedido.add(txtClienteId);

        JPanel btnsPedido = new JPanel();
        JButton btnCrearP = new JButton("Crear");
        JButton btnLeerP = new JButton("Leer");
        JButton btnActualizarP = new JButton("Actualizar");
        JButton btnEliminarP = new JButton("Eliminar");
        btnCrearP.setBackground(Color.GREEN);
        btnEliminarP.setBackground(Color.RED);
        btnActualizarP.setBackground(Color.ORANGE);

        btnsPedido.add(btnCrearP); btnsPedido.add(btnLeerP);
        btnsPedido.add(btnActualizarP); btnsPedido.add(btnEliminarP);

        pedidoModel = new DefaultTableModel(new Object[]{"ID", "Producto", "Cantidad", "Cliente ID"}, 0);
        JTable pedidoTable = new JTable(pedidoModel);

        pedidoPanel.add(formPedido, BorderLayout.NORTH);
        pedidoPanel.add(new JScrollPane(pedidoTable), BorderLayout.CENTER);
        pedidoPanel.add(btnsPedido, BorderLayout.SOUTH);

        // ADD PANELS
        add(clientePanel);
        add(pedidoPanel);

        // BOTONES CLIENTES
        btnCrearC.addActionListener(e -> {
            try {
                String nombre = txtNombre.getText().trim();
                String email = txtEmail.getText().trim();
                if (!nombre.isEmpty() && !email.isEmpty()) {
                    Cliente c = new Cliente(0, nombre, email);
                    crud.crear(c);
                    listarClientes();
                } else {
                    JOptionPane.showMessageDialog(this, "Nombre y Email son obligatorios.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        btnLeerC.addActionListener(e -> listarClientes());

        btnActualizarC.addActionListener(e -> {
            try {
                String idTxt = txtIdCliente.getText().trim();
                if (!idTxt.isEmpty()) {
                    int id = Integer.parseInt(idTxt);
                    String nombre = txtNombre.getText().trim();
                    String email = txtEmail.getText().trim();
                    if (!nombre.isEmpty() && !email.isEmpty()) {
                        Cliente c = new Cliente(id, nombre, email);
                        crud.actualizar(c);
                        listarClientes();
                    } else {
                        JOptionPane.showMessageDialog(this, "Nombre y Email son obligatorios.");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "ID es obligatorio para actualizar.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        btnEliminarC.addActionListener(e -> {
            try {
                String idTxt = txtIdCliente.getText().trim();
                if (!idTxt.isEmpty()) {
                    int id = Integer.parseInt(idTxt);
                    crud.eliminar("clientes", id);
                    listarClientes();
                } else {
                    JOptionPane.showMessageDialog(this, "Introduce un ID para eliminar.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        // BOTONES PEDIDOS
        btnCrearP.addActionListener(e -> {
            try {
                String producto = txtProducto.getText().trim();
                String cantidadTxt = txtCantidad.getText().trim();
                String clienteIdTxt = txtClienteId.getText().trim();

                if (!producto.isEmpty() && !cantidadTxt.isEmpty() && !clienteIdTxt.isEmpty()) {
                    int cantidad = Integer.parseInt(cantidadTxt);
                    int clienteId = Integer.parseInt(clienteIdTxt);
                    Pedido p = new Pedido(0, producto, cantidad, clienteId);
                    crud.crear(p);
                    listarPedidos();
                } else {
                    JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        btnLeerP.addActionListener(e -> listarPedidos());

        btnActualizarP.addActionListener(e -> {
            try {
                String idTxt = txtIdPedido.getText().trim();
                String producto = txtProducto.getText().trim();
                String cantidadTxt = txtCantidad.getText().trim();
                String clienteIdTxt = txtClienteId.getText().trim();

                if (!idTxt.isEmpty() && !producto.isEmpty() && !cantidadTxt.isEmpty() && !clienteIdTxt.isEmpty()) {
                    int id = Integer.parseInt(idTxt);
                    int cantidad = Integer.parseInt(cantidadTxt);
                    int clienteId = Integer.parseInt(clienteIdTxt);
                    Pedido p = new Pedido(id, producto, cantidad, clienteId);
                    crud.actualizar(p);
                    listarPedidos();
                } else {
                    JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        btnEliminarP.addActionListener(e -> {
            try {
                String idTxt = txtIdPedido.getText().trim();
                if (!idTxt.isEmpty()) {
                    int id = Integer.parseInt(idTxt);
                    crud.eliminar("pedidos", id);
                    listarPedidos();
                } else {
                    JOptionPane.showMessageDialog(this, "Introduce un ID para eliminar.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        setVisible(true);
    }

    private void listarClientes() {
        try {
            clienteModel.setRowCount(0);
            List<Cliente> lista = crud.listarClientes();
            for (Cliente c : lista) {
                clienteModel.addRow(new Object[]{c.getId(), c.getNombre(), c.getEmail()});
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void listarPedidos() {
        try {
            pedidoModel.setRowCount(0);
            List<Pedido> lista = crud.listarPedidos();
            for (Pedido p : lista) {
                pedidoModel.addRow(new Object[]{p.getId(), p.getNombre(), p.getCantidad(), p.getClienteId()});
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws SQLException {
        new AppGUI();
    }
}
